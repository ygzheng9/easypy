# Shiny Debugging Talk

This repo contains an article, slide deck, and sample code for the Shiny Debugging talk given at the [2016 Shiny Developer Conference](http://blog.rstudio.org/2015/10/29/shiny-developer-conference-stanford-university-january-2016/).
