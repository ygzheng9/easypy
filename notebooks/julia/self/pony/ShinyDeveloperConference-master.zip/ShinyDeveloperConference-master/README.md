# ShinyDeveloperConference
Materials collected from the First Shiny Developer Conference Palo Alto, CA January 30-31 2016
