library(leaflet)

function(req) {
  htmlTemplate("www/index.html")
}
